require "nvchad.options"

-- add yours here!
