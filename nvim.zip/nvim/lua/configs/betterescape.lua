return {
  require("better_escape").setup({
    mapping = { "jk" },
    timeout = 300,
  })
}
